package Datos;



public class Cuestionario {

	
	public int respuesta;
	
	
	public int getRespuesta() {
		return respuesta;
	}
	public void setRespuesta(int respuesta) {
		this.respuesta = respuesta;
	}
	public Cuestionario(int respuesta) {
		super();

		this.respuesta = respuesta;
	}
	public Cuestionario() {
		// TODO Auto-generated constructor stub
	}
	
	
	
}
