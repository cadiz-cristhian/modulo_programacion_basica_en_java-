package Datos;

public class ListaDB {
	public String db;
	public String url;
	public String usuario;
	public String password;
	
	public String getDb() {
		return db;
	}
	public void setDb(String db) {
		this.db = db;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public ListaDB(String db, String url, String usuario, String password) {
		super();
		this.db = db;
		this.url = url;
		this.usuario = usuario;
		this.password = password;
	}
	
	
}
